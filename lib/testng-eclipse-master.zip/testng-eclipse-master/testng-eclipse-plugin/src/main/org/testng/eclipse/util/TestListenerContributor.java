package org.testng.eclipse.util;

import org.testng.TestListenerAdapter;

public abstract class TestListenerContributor extends TestListenerAdapter
{
}
