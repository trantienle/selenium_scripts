package org.testng.eclipse.convert;

public class QueueTracker {

  public long getCurrentEnqueueCountTotal() {
    return 0;
  }

  public int getCurrentQueueSize() {
    return 0;
  }

  public boolean isRun() {
    return true;
  }

}
