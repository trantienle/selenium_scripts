package org.testng.eclipse.convert;


public class JUnit3Test4 extends MyTestCase {

  public JUnit3Test4(String name) {
    // Should not be removed
    super(name);
  }

  protected void setUp() throws Exception {
    // Should not be removed
    super.setUp();
  }

  public void _testFoo() {
  }
}
